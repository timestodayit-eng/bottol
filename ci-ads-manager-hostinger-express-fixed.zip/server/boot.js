import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// Hostinger Express preset may install dependencies and directly run this entry
// without running the Vite build. Build only if dist/index.html is missing.
const projectRoot = resolve(fileURLToPath(new URL('..', import.meta.url)));
const indexFile = resolve(projectRoot, 'dist', 'index.html');
if (!existsSync(indexFile)) {
  console.log('[CI boot] Frontend missing; building React frontend...');
  const viteBinary = resolve(projectRoot, 'node_modules', 'vite', 'bin', 'vite.js');
  if (!existsSync(viteBinary)) {
    console.error('[CI boot] Vite is not installed. Check npm install logs and package.json dependencies.');
    process.exit(1);
  }
  const result = spawnSync(process.execPath, [viteBinary, 'build'], {
    cwd: projectRoot,
    env: process.env,
    stdio: 'inherit',
    timeout: 120000
  });
  if (result.error || result.status !== 0 || !existsSync(indexFile)) {
    console.error('[CI boot] Frontend build failed. Inspect deployment/runtime logs.', result.error?.message ?? '');
    process.exit(1);
  }
}
console.log('[CI boot] Frontend ready. Starting Express server...');
await import('./index.js');
