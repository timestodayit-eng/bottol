# Hostinger Express startup fix

This edition corrects the message `Build frontend: npm run build` when Hostinger Express deployment runs a server entry but skips the Vite build.

1. Upload ALL files from this project to the GitHub repository root on the `main` branch, including `server/boot.js` and updated `package.json`. Do not upload `node_modules` or `.env`.
2. Hostinger -> deployment settings: Framework Express; Root `./`; Branch `main`; Node 20.x; Package Manager npm; **Entry file `server/boot.js`** (not `server/index.js`, and not `server.js`).
3. Keep actual environment variables with keys `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `JWT_SECRET`. Do not reveal their values.
4. Save and Redeploy. `server/boot.js` compiles the React bundle on startup only if `dist/index.html` is missing, then starts existing Express API in `server/index.js`.
5. Test `/api/health` (returns JSON) and `/` (login UI). If build fails, see Runtime logs for `[CI boot]` lines. If API returns `database: false`, verify MySQL variables/host.

Note: this is a pragmatic workaround for host providers without a configurable Express build step. A separate CI build and runtime stage is preferable at larger scale. This does not enable live Meta campaign publishing.
